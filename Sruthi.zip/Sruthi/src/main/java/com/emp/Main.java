package com.emp;


	public static void main(String[] args)
	{
		// TODO Auto-generated method stub

		Employee[]   objEmp=new Employee[];
		Employee[] objEmp1=new Employee[];
	
		
		PropChange(objEmp,objEmp1);
		
		System.out.println("objEmp"+objEmp);
		System.out.println("objEmp"+objEmp1);
		
		
	}


