package com.emp;

public class Employee {
private int  n1;
public	int n2;

public int getN1() {
	return n1;
}

public void setN1(int n1) {
	this.n1 = n1;
}
 public Object Employee(int  n1, int n2) {
	    this.n1 = n1;
		this.n2 = n2;
		public void  PropChange(Employee[] e1,Employee[] e2)
		{
		        int temp = e1.n1; 
		        e1.n1 = e2.n2; 
		        e2.n2 = temp; 
		        return null;
		}
 }
	
	
	
	
	}
	

