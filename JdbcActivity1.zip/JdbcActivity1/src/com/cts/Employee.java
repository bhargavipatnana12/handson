package com.cts;

public class Employee {

	
	int Employee_Id ;
	String Employee_Name;
	String Employee_Address;
	float  Employee_Salary;
	int  Employee_Contact_No ;
	int  Department_ID;
	
	
	public int getEmployee_Id() {
		return Employee_Id;
	}
	public void setEmployee_Id(int employee_Id) {
		Employee_Id = employee_Id;
	}
	public String getEmployee_Name() {
		return Employee_Name;
	}
	public void setEmployee_Name(String employee_Name) {
		Employee_Name = employee_Name;
	}
	public String getEmployee_Address() {
		return Employee_Address;
	}
	public void setEmployee_Address(String employee_Address) {
		Employee_Address = employee_Address;
	}
	public float getEmployee_Salary() {
		return Employee_Salary;
	}
	public void setEmployee_Salary(float employee_Salary) {
		Employee_Salary = employee_Salary;
	}
	public int getEmployee_Contact_No() {
		return Employee_Contact_No;
	}
	public void setEmployee_Contact_No(int employee_Contact_No) {
		Employee_Contact_No = employee_Contact_No;
	}
	public int getDepartment_ID() {
		return Department_ID;
	}
	public void setDepartment_ID(int department_ID) {
		Department_ID = department_ID;
	}
	
	
	
	
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employee(int employee_Id, String employee_Name, String employee_Address, float employee_Salary,
			int employee_Contact_No, int department_ID) {
		super();
		Employee_Id = employee_Id;
		Employee_Name = employee_Name;
		Employee_Address = employee_Address;
		Employee_Salary = employee_Salary;
		Employee_Contact_No = employee_Contact_No;
		Department_ID = department_ID;
	}
	
	
	
	
	
	
	
	
	
	
	
	
}
