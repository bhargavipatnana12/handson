package com.cts;

public class Department {
	int Department_ID;
String 	Department_Name;
String	Department_Head;
String 	Department_Description;

public int getDepartment_ID() {
	return Department_ID;
}
public void setDepartment_ID(int department_ID) {
	Department_ID = department_ID;
}
public String getDepartment_Name() {
	return Department_Name;
}
public void setDepartment_Name(String department_Name) {
	Department_Name = department_Name;
}
public String getDepartment_Head() {
	return Department_Head;
}
public void setDepartment_Head(String department_Head) {
	Department_Head = department_Head;
}
public String getDepartment_Description() {
	return Department_Description;
}
public void setDepartment_Description(String department_Description) {
	Department_Description = department_Description;
}
public Department(int department_ID, String department_Name, String department_Head, String department_Description) {
	super();
	Department_ID = department_ID;
	Department_Name = department_Name;
	Department_Head = department_Head;
	Department_Description = department_Description;
}
public Department() {
	super();
	// TODO Auto-generated constructor stub
}
	}
