package com.cts;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		EmployeeUploader eu=new EmployeeUploader();
		eu.storeDepartmentDetails();
		eu.storeEmployeeDetails();
	
		
		
		
		
	}

}
