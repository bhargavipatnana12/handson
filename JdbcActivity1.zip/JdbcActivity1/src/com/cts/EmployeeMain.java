package com.cts;

public class EmployeeMain {
	EmployeeMain e=new EmployeeMain();
}
