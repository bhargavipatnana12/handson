package com.cts;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class EmployeeUploader {
	Connection conn=null;
	PreparedStatement pstmt=null;
	
	public void 	storeDepartmentDetails() throws Exception {
		
		List<Department> list=new ArrayList<Department>();
          list.add(new Department(1 ,"Accounts"  , "Ramesh","AccountsDept"));
           list.add(new Department(2 ,  "Admin","Vijay","Admin Dept"));
           list.add(new Department(3   ,   "Sales " ,  "Vinod" , "Sales Dept"));
          list.add(new Department(4 ,   "HR" ,  "Mahesh"  , "HR Dept"));
          
          
          
try{
    Class.forName("com.mysql.cj.jdbc.Driver");
    conn=DriverManager.getConnection("jdbc:mysql://localhost:3305/marketing","root","root");
    String sql="insert into Department values(?,?,?,?)";
    pstmt=conn.prepareStatement(sql);
    
 
for(Department eu :   list) {
	
	pstmt.setInt(1,eu.getDepartment_ID());
	pstmt.setString(2,eu.getDepartment_Name());
	pstmt.setString(3,eu.getDepartment_Head());
	pstmt.setString(4,eu.getDepartment_Description());
	pstmt.addBatch();
	}


int[] rows=pstmt.executeBatch();
System.out.println(rows.length+"  : : data inserted");
 
}catch(SQLException e) {
	System.out.println("error");
	 
	 e.printStackTrace();

	}finally {

	

	 conn.close();

	}
}

	 
	 
		 
	 

void 	storeEmployeeDetails() {
		
	List<Employee> list=new ArrayList<Employee>();
    list.add(new Employee( 87  , "Vikram" ,   "Address 1  ",   12000 ,9878761212  ,  2));
    list.add(new Employee( 110 ,"Ajay"," Address 2",    18000 ,  9654376143     , 1));
    list.add(new Employee(98  ,  "Rajesh" ,  "Address 3  ",    11000  ,9965322212 ,4));
   list.add(new Employee(067   ,    "Ram "  ,  "Address 4 ",    19000,  807834373 ,3));
    list.add(new Employee( 045 , "Vimal" ,   "Address 5",   27000,      9932113221    ,  4));
    list.add(new Employee(987  ,   "Kiran ",    "Address 6 ",  21000  ,   7076337238  ,   2 ));
    
  try{
	    Class.forName("com.mysql.cj.jdbc.Driver");
	    conn=DriverManager.getConnection("jdbc:mysql://localhost:3305/marketing","root","root");
	    String sql="insert into Employee values(?,?,?,?,?,?)";
	    pstmt=conn.prepareStatement(sql);
	    
	for(Employee eu :   list) {
		
	
			
			pstmt.setInt(1,eu.getEmployee_Id());
			pstmt.setString(2,eu.getEmployee_Name());
			pstmt.setString(3, eu.getEmployee_Address());
			pstmt.setFloat(3,eu.getEmployee_Salary());
			pstmt.setInt(4, eu.getEmployee_Contact_No());
			
			pstmt.setInt(5,eu.getDepartment_ID());
			}


		int[] rows=pstmt.executeBatch();
		System.out.println(rows.length+"  : : data inserted");
		 
		
		
		
		
		
		
	}
		
	 catch(SQLException e) {
		 System.out.println("error");
		 e.printStackTrace();

		}finally {

		

		 conn.close();

		}
	

		 
		
		
	}
	
	
}
