package com.cts;

public class DepartmentMain {

	
	
	DepartmentMain d=new DepartmentMain();
	
	}
