package day5collectionsassesment.com;

public class EvenMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 

			 EvenNumber e = new EvenNumber();

			 e.storeEvenNumbers(20);

			 e.printEvenNumbers();
			 
			 //e.retrieveEvenNumber(12);


			 }
	}


