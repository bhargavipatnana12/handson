package day5collectionsassesment.com;

public class MainCountry {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Country countries = new Country();


			 

			 countries.storeCountryNames("India");

			 countries.storeCountryNames("USA");

			 countries.storeCountryNames("Africa");

			 countries.storeCountryNames("Pakistan");

			 countries.storeCountryNames("America");



			 System.out.println("America: " + countries.retrieveCountry("America"));

			 System.out.println("Singapore: " + countries.retrieveCountry("Singapore"));
	}
}
