package day5collectionsassesment.com;

import java.util.ArrayList;
import java.util.Scanner;

public class EvenNumber {

	
public ArrayList<Integer> A1 = new ArrayList<Integer>();

public ArrayList<Integer> storeEvenNumbers(int N) {
   
       for (int i = 2; i <= N; i++) {
    	   if (i % 2 == 0)
        A1.add(i);
    	   }
       System.out.println(A1);
       return A1;

}
  ArrayList<Integer> A2 = new ArrayList<Integer>();

ArrayList<Integer> printEvenNumbers() 

{
		  for (int j : A1) 
		  {
           A2.add(j * 2);
           System.out.println(j * 2);
           }
      
		    return A2;
         }


public  EvenNumber retrieveEvenNumberEnhancedForLoop(
	  ArrayList<Integer> array) {
	 
    for (EvenNumber array1 : A1[ ]) {
	        if (((Object) array1).getId().equals(A1)) {
            return A1;
        }
    }
	    return null;
	    }
}
}
}

//ArrayList<Integer> A11=A1;
//ArrayList<Integer>   retrieveEvenNumber(int N)
//       
//	public ArrayList<Integer> retrieveEvenNumberEnhancedForLoop(
//			  int i, ArrayList<Integer> A1) {
//			 
//    	   
//	for (Integer i1 : A1) {
//        if (((Integer) A1).getId().equals(i1)) {
//            return A1;
//        }
//    }
//    return null;
//       }
//}
//       







