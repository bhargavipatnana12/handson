package day5collectionsassesment.com;

import java.util.HashMap;

public class MainCountryMap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CountryMap countryMap = new CountryMap();



		 countryMap.storeCountryCapital("India", "Delhi");

		 countryMap.storeCountryCapital("Pakistan", "Karachi");

		 countryMap.storeCountryCapital("Japan", "Tokyo");



		 System.out.println(countryMap.retrieveCapital("India"));

		 System.out.println(countryMap.retrieveCountry("Karachi"));

		 System.out.println(countryMap.toArrayList());



		 HashMap<String, String> M2 = countryMap.swapKyeValue();

		 System.out.println(M2);

		 }

		}




	


