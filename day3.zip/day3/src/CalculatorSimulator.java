
public class CalculatorSimulator {
     public static void main(String args[])
     {
    	 
     }
	
	
}
