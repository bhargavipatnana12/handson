package com.cognizant.shapes;

public class Area {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Circle c1=new Circle();
     System.out.println(c1.calculateCircleArea(5));
     System.out.println(c1.calculateCircumference(6));
     
     
     
    
     
	}

}
