package com.cognizant.shapes;

public class SimpleInterestCalculator {

	double principalamount;

	int numberofyears;

	double Simpleinterest;

	double calculateSimpleInterest(double principalamount, double numberofyears)

	{

		if (principalamount > 100000)

		{

			if (numberofyears > 10)

			{

				return Simpleinterest = principalamount * numberofyears * 10 / 100;

			}

			else

			{

				return Simpleinterest = principalamount * numberofyears * 9.5 / 100;

			}

		}

		else if (principalamount < 100000)

		{

			if (numberofyears < 10)

			{

				return Simpleinterest = principalamount * numberofyears * 5 / 100;

			}

			else

			{

				return Simpleinterest = principalamount * numberofyears * 4.5 / 100;

			}

		}

		return numberofyears;

	}

}
