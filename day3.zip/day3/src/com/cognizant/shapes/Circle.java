package com.cognizant.shapes;

public class Circle {
//public float radius;
	float radius;
//public float pi;
	float pi;
	float area;
	float circumference;

	 Circle() {
		radius = 1.5f;
		pi = 3.14f;
		System.out.println(radius);
	}

	 Circle(float radius) {
		this(radius, 3.14f);
		this.radius = radius;
	}

	Circle(float radius, float pi) {
		this.radius = radius;
		this.pi = pi;
	}

	float calculateCircleArea(float radius) {
		
		area = pi * radius * radius;

		
		return area;

		
	}

	float calculateCircumference(float radius) {
	
		circumference = 2 * 3.14f * radius;
	

		return circumference;
	}

}