package com.cognizant.shapes;

public class Calculator {

	public static void main(String[] args) {



			SimpleInterestCalculator c=new SimpleInterestCalculator();

			System.out.println("The interest amount for a principal 200000 and years 12 is   "+c.calculateSimpleInterest(200000,12));

			c.calculateSimpleInterest(50000,12);

			}




	}


