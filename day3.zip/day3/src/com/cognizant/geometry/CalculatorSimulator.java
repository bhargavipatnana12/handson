package com.cognizant.geometry;


public class CalculatorSimulator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	TaxCalculator t=new TaxCalculator();
	
	
	
	try {
	t.calculateTax("sruthi", true, 40000);
	}
	catch(CountryNotValidException c)
	{
		System.out.println("The employee should be an Indian citizen for calculating tax");
	}
	catch(EmployeeNameInvalidException en)
	{
		System.out.println("The employee name cannot be empty");
	}
	catch(TaxNotEligibleException te)
	{
		System.out.println("The employee does not need to pay tax");
	}
	}
}