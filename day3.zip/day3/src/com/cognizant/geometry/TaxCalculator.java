package com.cognizant.geometry;

public class TaxCalculator {
	String empName = "sruthi";
	boolean isIndian = true;
	double empSal = 400000;
	double taxAmount = 500000;

	public double calculateTax(String empName, boolean isIndian, double empSal)
		throws CountryNotValidException, EmployeeNameInvalidException, TaxNotEligibleException
	{

	    if(!isIndian)
		{
			throw new CountryNotValidException("is not an indian");
		}
			
			if(empName==null)
			{
				throw new EmployeeNameInvalidException("invalid");
			}
				if(empSal>100000 && isIndian==true)
				{
					 taxAmount=empSal*8/100;
					System.out.println(taxAmount);
				}
						if(empSal>50000 && empSal<100000 && isIndian==true)
					{
					 taxAmount=empSal*6/100;
						System.out.println(taxAmount));
					}
					if(empSal>30000 && empSal<50000 && isIndian==true)
					{
					 taxAmount=empSal*5/100;
						System.out.println(taxAmount));
					}
						if(empSal>10000 && empSal<30000 && isIndian==true)
					{
						taxAmount=empSal*4/100;
						System.out.println(taxAmount);
					}
					else	
					{
				throw new TaxNotEligibleException(taxAmount);
					}
				
				}
			
			}
	
