package com.cognizant.geometry;

public class EmployeeNameInvalidException extends Exception {
	
	EmployeeNameInvalidException(String empName) {
			super();

		}
}
