package com.cognizant.geometry;

public class CountryNotValidException extends Exception {
	CountryNotValidException(String string) {
		super();

	}
}
