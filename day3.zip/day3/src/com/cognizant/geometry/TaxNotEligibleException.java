package com.cognizant.geometry;


	public class TaxNotEligibleException extends Exception {
		public TaxNotEligibleException(double taxAmount) {
			// TODO Auto-generated constructor stub
			super();
		}
}
