package com.cts;

public class AgeException extends Exception {
           AgeException(String msg){
        	   super(msg);
           }
}
