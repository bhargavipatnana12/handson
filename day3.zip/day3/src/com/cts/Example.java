package com.cts;

public class Example {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
	/*	Employee e=new Employee();
		e.id=3;
		e.name="sruthi";
		e.salary=25000;
	//	e.dowork();
		e.addr=new Address();
		
		//Address ad=new Address()	;
		e.addr.city="hyd";
		e.addr.state="vzg";
	//	e.addr=ad;
		System.out.println(e.id);
		System.out.println(e.name);
		System.out.println(e.salary);
		System.out.println(e.addr.city);
		System.out.println(e.addr.state);*/
	/*	Employee e1=new Employee();
				e1.id=2;
		e1.name="susmi";
		e1.salary=300000;
		e1.dowork();*/
		
//		Employee e1=new Employee();
//		e1.id=3;
//		e1.name="sruthi";
//		e1.salary=25000;
//		Employee.company="cts";
//		e1.dowork();
//		Employee.showCompany();
//		
		
		
	/*	Employee e2=new Employee();
		e2.id=3;
		e2.name="sruthi";
		e2.salary=25000;*/
		
	}

}
