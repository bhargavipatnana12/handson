package com.cts;

public class Atmkamain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Atm atm=new Sbibank();
atm.atmDeposit(1000);
	atm.atmWithdraw(3000);
	

}
}
