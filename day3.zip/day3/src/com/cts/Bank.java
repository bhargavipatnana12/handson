package com.cts;

public abstract  class Bank {
                   int balance;
                   int amount;
                   public void doDeposit(int amount)
                   {
                	   this.balance+=amount;
                	   System.out.println(this.balance);
                   }
                   public void doWithdraw(int amount)
                   {
                	   this.balance+=amount;
                	   System.out.println(this.balance);
                   } 
                   public abstract void calculateInterest();
                   {
                	   this.balance+=amount;
                	   System.out.println(this.balance);
                   }
}
