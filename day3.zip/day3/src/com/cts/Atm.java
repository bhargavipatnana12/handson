package com.cts;

public interface Atm {

	public void atmDeposit(int amount);
	public void atmWithdraw(int amount);
	
	 
}
