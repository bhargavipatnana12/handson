package com.cts;

public class Employee {
	            
public int  id;             //state
	String name;
	int salary;
	//static string company;
//	protected int age;
//	Address addr;
/*static
{
	System.out.println("static block executed");
	}
	void dowork()                  //behavior
	{
		System.out.println("Employee "+name+" works for  "+salary);
	}
	public static void showCompany()
	{
		System.out.println(company);
	}
}*/
 Employee() {
		System.out.println("emp1");
	}
	
	
}