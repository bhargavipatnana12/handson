package com.cts;

public class SalException extends RuntimeException {

	
        SalException(String sal){
     	   super();
        }}


