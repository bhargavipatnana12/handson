package com.cts;

public class Student {

	
       public int rollno;
       String name;
       int m1;
       int m2;
       int m3;
        
       public void totalMarks() {
    	   
     
	int  total=m1+m2+m3;
	System.out.println(total);
   }
}

