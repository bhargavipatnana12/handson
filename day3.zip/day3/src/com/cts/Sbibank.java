package com.cts;

public class Sbibank extends Bank implements Atm {
	
	
//	@override
//	public void calculateInterest() {
//		this.balance += (this.balance * 8) / 100;
//		System.out.println(this.balance);
//	}
	
	public void doDeposit(int amount) {
	this.balance += (this.balance * 4) / 100;
	System.out.println(this.balance);

	}
	
	public void doWithdrawt() {
	this.balance -= (this.balance * 4) / 100;
		System.out.println(this.balance);
		}
	//public void doWithdrawt() {
//this.balance -= (this.balance * 4) / 100;
//		System.out.println(this.balance);
//	}
//	public void doDeposit() {
//		this.balance += (this.balance * 5) / 100;
//		System.out.println(this.balance);
//	}

}
