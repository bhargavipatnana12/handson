package com.cts;

public class MainBank {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       Bank b=new Sbibank();
       b.calculateInterest();
       b.doDeposit(67);
       b.doWithdraw(90);
	}

}
