package com.cts;
import static java.lang.Math.*;
import com.cts.Employee;

public class Math {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(pow(10,2));
		System.out.println(min(10,5));
		System.out.println(abs(-100));
		System.out.println(showcompany());
	}

	private static char[] showcompany() {
		// TODO Auto-generated method stub
		return null;
	}

}
