package com.cts;

public class Sub {


		public static void main(String[] args) {
			// TODO Auto-generated method stub
	Student student=new Student();

	student.rollno=1;
	student.name="sri";
	student.m1=90;
	 student.m2=80;
	student.m3=70;
	student.totalMarks();
		}

	}

	
	
	

