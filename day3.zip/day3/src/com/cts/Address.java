package com.cts;

public class Address {

	String city;
    String state;
    
    
}
