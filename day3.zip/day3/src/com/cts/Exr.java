package com.cts;

public class Exr {
	public static void main(String[] args) {
		try {
			checkSal(30000);
		} catch (SalException e) {
			System.out.println(e.getMessage());
		}

	}

	public static void checkSal(int sal) throws SalException {
		if (sal<1000) {
			throw new SalException("accepted");
		} else {
			System.out.println("declined");
		}
	}
}
