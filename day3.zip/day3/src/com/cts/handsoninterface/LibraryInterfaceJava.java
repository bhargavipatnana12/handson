package com.cts.handsoninterface;

public class LibraryInterfaceJava {


		public static void main(String[] args) {
		LibraryUser l =new KidUsers();
		l.registerAccount(10,"Kids");
		l.requestBook(18, "Fiction");

		LibraryUser l1 =new AdultUser();
		l1.registerAccount(5,"Kids");
		l1.requestBook(23,"Fiction");
		}

		}


