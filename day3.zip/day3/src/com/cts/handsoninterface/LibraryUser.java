package com.cts.handsoninterface;


	public interface LibraryUser {
		void registerAccount(int age,String bookType);
		public void requestBook(int age,String bookType);
		}



