package com.cts;

public class Hdfcbank extends Bank implements Atm{

	@Override
	public void calculateInterest() {
		// TODO Auto-generated method stub
this.balance+=(this.balance*6)/100;
System.out.println(this.balance);
	}
	@Override
	public void atmDeposit(int amount)
	{
		doDeposit(amount);
	}
	@Override
	public void atmWithdraw(int amount)
	{
		doDeposit(amount);
	}

}
