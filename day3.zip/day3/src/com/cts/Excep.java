package com.cts;

public class Excep {

	public static void main(String[] args) {
// TODO Auto-generated method stub
	int a=10;
	int b=0;
		int c=a/b;
	System.out.println(c);
	
		}
                    method1();

	}
	public static void method(String[] args) {
}



