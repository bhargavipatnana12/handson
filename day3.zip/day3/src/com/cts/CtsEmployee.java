package com.cts;

public class CtsEmployee  extends Employee{

//	public static void main(String[] args) {
		// TODO Auto-generated method stub

//	}

	CtsEmployee(){
		System.out.println("cts employee");
	}
	
}
