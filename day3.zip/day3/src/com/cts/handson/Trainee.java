package com.cts.handson;


public class Trainee extends Employee {

	public Trainee(long employeeid, String employeeName, String employeeAddress, long employeePhone,double basicsalary) {
		super(employeeid,employeeName,employeeAddress,employeePhone,basicsalary);
	}

	}

