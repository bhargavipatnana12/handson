package com.cts.handson;



public class Manager extends Employee {

	// TODO Auto-generated method stub

	public Manager(long employeeid, String employeeName, String employeeAddress, long employeePhone,double basicsalary) {
		super(employeeid,employeeName,employeeAddress,employeePhone,basicsalary);
	}
		
		@Override
		public double calculateTransportAllowance() {
			transportAllowance = 15*basicSalary/100;
			System.out.println(transportAllowance);
			return transportAllowance;
		
		}
		
		
	}
	


