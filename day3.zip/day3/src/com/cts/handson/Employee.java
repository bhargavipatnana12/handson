package com.cts.handson;

public class Employee {
	long employeeId;
    String employeeName;
    String employeeAddress;
    Long employeePhone;
    double basicSalary;
    double specialAllowance = 250.80;
    double Hra = 1000.5;
    double transportAllowance;
	
	public double calculateSalary()
    {
		double salary = basicSalary + (basicSalary * specialAllowance / 100) + (basicSalary * Hra / 100);
		System.out.println(salary);
		return salary;
	}

	public double calculateTransportAllowance()
	{
       transportAllowance = basicSalary*10/100;
		System.out.println(transportAllowance);
		return transportAllowance;
	}

	public Employee(long employeeid, String employeeName, String employeeAddress, long employeePhone,double basicSalary) 
	{
		super();//doubt
		this.employeeId = employeeid;
		this.employeeName =employeeName;
		this.employeeAddress = employeeAddress;
		this.employeePhone = employeePhone;
		this.basicSalary=basicSalary;
	//	System.out.println("employeeid: " + "employeeName: " + "employeeAddress: " + "employeePhone: " +"basicSalary");
	}
}



	