package com.cts.handson;

public class InheritanceActivity {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee e = new Manager(126534, "Peter", "Chennai India", 65000,4500000);

		e.calculateSalary();
	    e.calculateTransportAllowance();

	Employee t=new Trainee(29846,"Jack","Mumbai India",442085,45000);
	      t.calculateSalary();
           	t.calculateTransportAllowance();
}
}