package com.ctc.day5;

public interface ConcatInterface
{
	
	public String doConcat(String s,String s1);
	


}
