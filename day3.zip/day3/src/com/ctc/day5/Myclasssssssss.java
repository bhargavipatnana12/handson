package com.ctc.day5;

public class Myclasssssssss implements MyInterface {
@Override
	public void letc() {
		System.out.println("letc called");
	}
	
}
