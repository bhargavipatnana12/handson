package com.ctc.day5;
@FunctionalInterface
public interface MyInterface {

	public void letc();//one abstract method--------functional interface

//	public default void methodDef() {
//		System.out.println("hi");
//	}
//
//	public static void methodStatic() {
//		System.out.println("static ");
//	}
	
	
	
	
}
