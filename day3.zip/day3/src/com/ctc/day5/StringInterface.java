package com.ctc.day5;

public interface StringInterface {
	public void change2Upper(String s);
	 
		 
	
}
