package com.ctc.day5;

public class FactorialInterface
{
	public void findFact(){
	}
}
