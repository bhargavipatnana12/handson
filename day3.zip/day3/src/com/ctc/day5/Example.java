package com.ctc.day5;

import java.io.File;
import java.util.*;

public class Example {
	public static void main(String[] args) {
//	  Employee emp=new Employee();
//	  
//		  emp.id=100;
//		  emp.name="sruthi";
//		  emp.salary=28000;
//		  emp.dowork();
//		  System.out.println(emp);
//		  System.out.println(emp.hashCode());

//		  Employee emp1=emp;
//		  emp1.name="sriiii";
//		  System.out.println(emp.name);
//	  Employee emp1=new Employee();
//	  {
//		  emp1.id=100;
//		  emp1.name="sruthi";
//		  emp1.salary=28000;
//	  boolean flag=emp==emp1;
//		  System.out.println(emp==emp1);
//	  boolean flag=emp.equals(emp1);
//	  System.out.println(flag);
// }

//  String s="hi";
//  String s1=new String("hello");
//  boolean flag=s==s1;
//  
//  System.out.println(flag);
//  
//}
//  String s3="world";
//  String s4=new String("world");
//  
//
//  System.out.println(s3.equals(s4));
//  
//  System.out.println(s3==s4);
//  }
	
//		Employee emp = new Employee();
//
//		emp.id = 100;
//		emp.name = "sruthi";
//		emp.salary = 28000;
//		System.out.println(emp.id  + "  is   " +emp.name + "   is    " + emp.salary);
//		
//		Employee[ ] empAr = new Employee[3];
//		empAr[0] = emp;
//		empAr[1] = new Employee();
//		
//		empAr[1].id = 200;
//		empAr[1].name = "srinu";
//		empAr[1].salary = 34000;
//empAr[2] = new Employee();
//		
//		empAr[2].id = 500;
//		empAr[2].name = "sruthi";
//		empAr[2].salary = 78000;
//
//		
//for(Employee e : empAr)
//{
//	System.out.println(e);
//}
//	}
//	List<Integer> list=new ArrayList();
//		list.add(100);
//		list.add(40);
//		list.add(50);
//		list.add(60);
//		
//		System.out.println(list);
//		Collections.sort(list);
//		System.out.println(list);
//		
//		
//		List<Employee> list=new ArrayList();
//	list.add(new Employee(300,"w",40000));
//	list.add(new Employee(500,"o",70000));
//	list.add(new Employee(600,"i",50000));
//	
//	for(int i=0;i<list.size();i++) {
//	System.out.println(list.get(i));
//	}
//	System.out.println();
//	for(Employee e : list)
//		{
//		System.out.println(e);
//}

//List<Employee> list=new ArrayList();
//	list.add(new Employee(300,"w",40000));
//list.add(new Employee(500,"o",70000));
//	list.add(new Employee(600,"i",50000));
//		Iterator<Employee> it=list.iterator();
//		while(it.hasNext())
//		{
//			Employee e=it.next();
//			if(e.id==300) {
//				it.remove();
//				
//				
//				
//			}
//		}

//	Collections.sort(list);
//	System.out.println(list);
//		
	
	
	////set     ....
	Set<Integer> set=new HashSet<Integer>();
	set.add(10);
	set.add(40);
	
	set.add(50);
	System.out.println(set);
	
	System.out.println(set.size());
	System.out.println(set.contains(10));
	for(int i:set) {
		System.out.println(i);
	}
	Itereator<Integer> k=Integer.Iterator();

	for(Integer i :set )
	{
System.out.println(i);
	
	
	
	
	
	
	
	
	
	
	
}
}

