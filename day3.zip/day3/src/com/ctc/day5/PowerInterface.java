package com.ctc.day5;

public class PowerInterface {
 public void findPower(int v,int p)
 {
	 
}
}