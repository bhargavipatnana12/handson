package com.ctc.day5;

import java.util.HashSet;
import java.util.Set;
import java.util.*;
import java.io.File;


public class TreeSet {
	public static void main(String[] args) {
		
		
//		Set<Integer> set=new TreeSet();
//		set.add(10);
//		set.add(40);
//		System.out.println("set");
//	}
		
		
//		Map<Integer,String> map=new HashMap();
//		map.put(1,"sruthi");
//		map.put(2,"suhithi");
//		map.put(3,"skklshi");
//		System.out.println(map);
		
		
		Map<Integer,String> map=new TreeMap();
		map.put(1,"sruthi");
		map.put(2,"suhithi");
		map.put(20,"skklshi");
		System.out.println(map);
		
		
	}
	
}
