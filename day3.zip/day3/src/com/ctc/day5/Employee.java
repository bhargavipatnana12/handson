package com.ctc.day5;
import java.lang.*;
public class Employee extends Object implements Comparable<Employee>{

	
	public int id;
	String name;
	int salary;
	
//	public Employee() {
//		super();
//		// TODO Auto-generated constructor stub
//	}
//	public Employee(int id, String name, int salary) {
//		super();
//		this.id = id;
//		this.name = name;
//		this.salary = salary;
//	}
//	public int hashcode()
//	{
//		return id;
//	}
//	
	public int hashcode()
	{
		int k=super.hashCode();
		System.out.println(k);
		return k;
	}
	
	
//	public boolean equals(Object o) {
//		Employee e=(Employee o);
//		return this.id==e.id && e.name.contentEquals(this.name);
//	}
    @Override
	public String toString()
     {
              return id+ "is" +name + " is " + salary ;
	}
  
	void dowork()
	{
		System.out.println("Employee"+ this.name+"salary"+this.salary);
	}
	
	public boolean equals(Object obj) {
		Employee e=(Employee ) obj;
		
		return this.id==e.id && this.name.equals(e.name);
		}
//	public int compareTo(Employee o)
//	{
//		System.out.println("compareto");
//		if(this.id>o.id) {
//			return 100;
//		}else {
//			return -100;
//		}
	
	//sorted order for names
	
@Override
	   public int compareTo(Employee o)
	   {
		   return this.name.compareTo(o.name);
			   
		   

		   
		   
		   
		   
		   
		   
		   
		   
	}


	        }
		
		
	
	


