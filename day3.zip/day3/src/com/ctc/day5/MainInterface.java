package com.ctc.day5;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Comparator;
import java.util.stream.IntStream;

import java.sql.Statement;



public class MainInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//MyInterface m=new MyInterface();
//m.letc();
//m.methodDef();
//MyInterface.methodStatic();
//letc(m);
//		public static void letc(MyInterface m)
//		{
//			m.letc();
//		}
//---------------prints hi=================
//		MyInterface m = new MyInterface() {
//			@Override
//			public void letc() {
//				System.out.println("hii");
//			}
//		};
//
//		letc(m);
//	}
//
//	public static void letc(MyInterface m) {
//		m.letc();
//---------------------------------prints hii-------creating obj in method
//		letc(new MyInterface() {
//			@Override
//			public void letc() {
//				System.out.println("hii");
//			}
//		});
//
//	}
//	
//
//	public static void letc(MyInterface m) {
//		m.letc();
//		
		
		
	//	---------------------prints bal..------------
//	letc(new Atm() {
//		int bal;
//		@Override
//		public void atmDeposit(int amount) {
//			this.bal+=amount;
//			System.out.println(this.bal);
//	}
//		@Override
//		public void atmWithdraw(int amount) {
//			this.bal-=amount;
//			System.out.println(this.bal);
//	}
//	});
//	}
//		
//public static void letc(Atm m)
//{
//	m.atmDeposit(1000);
//	m.atmWithdraw(50000);
		//-----------------prints hi------------
//		method1(new MyInterface()
//				{
//			
//				@Override
//			public void letc() {	
//					System.out.println("hii");
////		
//			}
//				});
//		
//}
//	public static void method1(MyInterface m)
//	{
//		m.letc();
		
		
//		method1(()->System.out.println("hiiiiii"));
//	}
//	public static void method1(MyInterface m)
//	{
//		m.letc();
		
		
	
		//================fact of 5
		
//		method1(new FactorialInterface() {
//			
//		@Override
//		public void findFact() {	
//			int i,fact=1;
//			int n=5;
//			for(i=1;i<=n;i++) {
//				fact=fact*i;
//			}
//	
//		System.out.println(fact);
//		}
//		});
//		}
//		
//	public static void method1(FactorialInterface m)
//	{
//		m.findFact();
		
		
	//	-----------------power===============
//		method1 ((v,p) -> Math.pow(v,  p));
//	}

//		method1(new PowerInterface() {			
//@Override
//	public int findPower(int v,int p) {	
//	
//	return Math.pow(v,p);
//}
//		});
//	}
//	
//	int number = 2;
//	p=5;
//    int result=1;
//    
//    int i = p;
//    for (;i != 0; --i)
//    {
//        result = result*number;
//    }
//    System.out.println(number+"^"+p+" = "+result);
//
//
//	}
//	});
//	}
	
	//--------------METHOD REFEFRENCE-----------
	
//	method1(Math : : pow);
//}
//
//	
//	
//public static void method1(PowerInterface m)
//	{
//	System.out.println(m.findPower(2,5));	
		
		
		
///----------		stringinterface
//		
//			method1(new StringInterface() {
//		@Override
//		public String change2Upper(String s) {
//			return s.toUpperCase();			
//		}
//		});
//	}
//	public static void method1(StringInterface m)
//	{
//		System.out.println(m.change2Upper("hello"));	
//	
//		method1(String :: concat);
//	}
//		
//		public static void method1(ConcatInterface m)
//	{
//		System.out.println(m.doConcat("hello","hiiii"));	
//		
		//int sum1 = IntStream.of(1, 2, 3, 4, 5)
    //            .filter(n -> n % 2 == 0).sum(); 
		
//		method4(new EvenInterface() {
//			
//			@Override
//			public int findSumEven(int n) {
//				int t=0;
//				for(int i=2;i<=10;i++) {
//					t=t+1;
//					i++;
//				}
//			return t;
//			
//			}
//		});
//		
//		}
//	
//	public static void method4(	EvenInterface m)
//	{
//	System.out.println(m.findSumEven(10));	
//	}	
//	
//}
		//method4(new EvenInterface() {
			
		
//int findSumEven = IntStream.of(1, 2, 3, 4, 5,6,7,8,9,10)
//.filter(n -> n % 2 == 0).sum();

//@Override
//public int findSumEven(int n) {
//	// TODO Auto-generated method stub
//	intn, n1;
//	int findSumEven = IntStream.of(1, 2, 3, 4, 5,6,7,8,9,10)
//			.filter(n -> n1 % 2 == 0).sum();
//
//	return 0;
//} 
//		
//		});
//	}
//public static int method4(EvenInterface m) {
//System.out.println(m.findSumEven(10));
//return 0;	
		
		Connection conn=null;
		Statement stmt=null;
		try {
			//register driver with drivermanager
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydata","root","root");
		//	System.out.println("connected to mysql");
			stmt=conn.createStatement();
			
			stmt.execute("insert into employee values(1,1000)");
			
			
			
			System.out.println("data inserted successfully");
			
			
		}catch(Exception e) {
			
			e.printStackTrace();
	}finally {
		try {
			conn.close();
		}catch(SQLException e) {
	}
		}
	}
}
