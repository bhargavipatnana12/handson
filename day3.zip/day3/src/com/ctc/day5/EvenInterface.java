package com.ctc.day5;

public interface EvenInterface {
	public int findSumEven(int n);
}
