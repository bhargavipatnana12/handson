package com.info;

public class Telephone {
	
	
	public Number makeCall()
	{
		System.out.println("press button and dial key");
		return 0;
	}
	
	public Number receiveCall()
	{
		System.out.println("press  GREEN key");
		return 0;
	}
	public Integer sendsmsl()
	{
		System.out.println("send sms");
		return null;
	}
}
