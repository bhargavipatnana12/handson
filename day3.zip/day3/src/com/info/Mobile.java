package com.info;

public class Mobile extends Telephone {
@Override
public Integer makeCall()
{
	System.out.println("press button and dail key");
	return null;
}
@Override
public Integer receiveCall()
{
	System.out.println("press green  button");
	return null;
	
}
public Integer sendsmsl()
{
	System.out.println("send sms.........");
	return null;
}
}
