package com.cts.threads;

public class LoaderThread  implements Runnable{
	Integer startNumber;
	Integer lastNumber;
	
	
	
	LoaderThread(Integer startNumber, Integer lastNumber) {
		this.startNumber=startNumber;
		this.lastNumber=lastNumber;
	}
	@Override
	public void run()
	{
		ListLoader l=new  ListLoader();
		l.loadList(startNumber,lastNumber);
	}

}
