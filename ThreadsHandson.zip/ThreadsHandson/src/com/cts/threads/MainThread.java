package com.cts.threads;

public class MainThread {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		long time1 = System.currentTimeMillis();
		Thread thread1 = new Thread(new LoaderThread(0, 50000000));
		thread1.start();

		long time2 = System.currentTimeMillis();
		Thread thread2 = new Thread(new LoaderThread(50000000, 10000000));
		thread2.start();
		thread1.join();
		thread2.join();

		long responsetime = time1 - time2;
		System.out.println(responsetime);

	}

}
