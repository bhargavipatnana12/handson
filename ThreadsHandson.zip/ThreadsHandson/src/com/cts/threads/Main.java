package com.cts.threads;

public class Main {

	public static void main(String[] args) {
		
	
		// TODO Auto-generated method stub
ListLoader l=new  ListLoader();



long t=System.currentTimeMillis();
l.loadList(0, 10000000);

long t1=System.currentTimeMillis();
long responsetime=t-t1;
System.out.println(responsetime);





	}

}
