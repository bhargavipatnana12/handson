package com.cts.threads;

import java.util.ArrayList;

public class ListLoader {
	
	ArrayList<Integer> l=new ArrayList<Integer>();
	
	   void loadList(Integer startNumber, Integer lastNumber) {
		   
		   for(int i=startNumber;i<lastNumber;i++) 
		   {
		   
			   l.add(i);
		    System.out.println(i);
	   }
	   
		   
		   
		   
		   
		   
}
}
