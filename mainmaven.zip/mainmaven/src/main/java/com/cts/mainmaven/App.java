package com.cts.mainmaven;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	
 /*   	try { 
          //  String url = "jdbc:msql://200.210.220.1:1114/Demo"; 
            Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydatabase","root","root");
            Statement st = conn.createStatement(); 
          /*  st.executeUpdate("INSERT INTO Employee " + 
                "VALUES (1001, 'Susmi', 20000)"); 
            st.executeUpdate("INSERT INTO Employee " + 
                    "VALUES (1002, 'Sruthi', 30000)"); 
            st.executeUpdate("INSERT INTO Employee " + 
                    "VALUES (1003, 'Sravs', 40000)"); */
          //  st.executeUpdate("UPDATE   Employee SET Name=’ravi’ where  Name=’sruthi’");
            	//	update student set StudentName=’Manoj’ where StudentName=’Kumar’  
      //      String sql = "delete * from employee where id=1001";
          //  System.err.println("data inserted "); 
   /*         System.out.println("data delete "); 
            conn.close(); 
        } catch (Exception e) { 
            System.err.println("Got an exception! "); 
            System.err.println(e.getMessage()); 
        } */
    	
    	String sql = "delete from employee where emp_id=1";

         //   Connection conn=null;
			//Statement stmt = conn.createStatement();
        
        try
        {
        	Connection conn=null;
        	Statement stmt = conn.createStatement();
        	Connection conn1=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydatabase","root","root");
                Statement st = conn1.createStatement(); 
        
          
          stmt.executeUpdate(sql);
          System.out.println("Record deleted successfully");
        } catch (SQLException e) {
          e.printStackTrace();
        }
      }

}

    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    /*	try {
    		
    		Class.forName("com.mysql.cj.jdbc.Driver");
    		
    		Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydatabase","root","root");
    	
       System.out.println( "connected" );
    	}
    	catch(Exception e) {
    		

    }*/
    	
    /*	Connection conn = null;
        try {
        //  String url = "jdbc:sqlite:path-to-db-file/chinook/chinook.db";
          conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydatabase\",\"root\",\"root\"");

          Statement stmt = null;
          String query = "select * from employee";
          try {
              stmt = conn.createStatement();
              ResultSet rs = stmt.executeQuery(query);
              
              while (rs.next()) {
                  String name = rs.getString("title");
                  System.out.println(name);
              }
         
          } catch (SQLException e ) {
              throw new Error("Problem", e);
         
          } finally {
              if (stmt != null) { stmt.close(); }
          }

        } catch (SQLException e) {
            throw new Error("Problem", e);
        
        } finally {
          try {
            if (conn != null) {
                conn.close();
            }
         
          } catch (SQLException ex) {
              System.out.println(ex.getMessage());
          }
        }*/
     
    	
    	
    	
    	
    	
    	
    	
    	
    	
    
    	
    	
    	
    	
    	
    	