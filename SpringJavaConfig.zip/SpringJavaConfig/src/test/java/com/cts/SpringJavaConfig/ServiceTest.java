package com.cts.SpringJavaConfig;
import static org.junit.Assert.*;
import java.sql.Connection;
import java.util.Arrays;
import java.util.List;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

public class ServiceTest {
static Connection con=null;
Service service=null;

@BeforeClass
public static void init()
{

 System.out.println("init");

 ApplicationContext cxt=new AnnotationConfigApplicationContext(JavaConfig.class);

 DriverManagerDataSource ds=cxt.getBean(DriverManagerDataSource.class);
 try {

 con=ds.getConnection();

 }catch(Exception e) {

  e.printStackTrace();
 }

 }
 @Before
public void setUp() throws Exception {

 //System.out.println("Before exceuted");
 service=new Service();

 }

@After
 public void tearDown() throws Exception {

 //System.out.println("After exceuted");

 service=new Service();

 }


 @Test
 public void testCountCustomers() {

 //fail("Not yet implemented");

 assertEquals(10, service.countCustomer(con));

 }

 @Test
public void testCountActinameonMovies() {

 //fail("Not yet implemented");

 List<String> list=service.countActionMovies(con);

 assertArrayEquals(list.toArray(), Arrays.asList("super","BAHUBALI", "SYRA", "SURYA","DARK KNIGHT").toArray());

   }
}