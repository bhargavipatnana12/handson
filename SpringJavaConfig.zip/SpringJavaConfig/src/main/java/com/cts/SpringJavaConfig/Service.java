package com.cts.SpringJavaConfig;

import java.sql.Connection;
import java.lang.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Service {
     
	public int countCustomer(Connection connection) {
		
		String sql="select count(customer_name) from customer_master";
		int count=0;
		try {
			PreparedStatement pstmt=connection.prepareStatement(sql);
			ResultSet rs=pstmt.executeQuery();
			while(rs.next()) {
				count=rs.getInt(1);
			}
	      	}catch(Exception e)
		{
			e.printStackTrace();}
		
		return count;
	}
			public List<String> countActionMovies(Connection connection)
	{
		
		String sql="select movie_name from movies_master where movie_category='action'";
		List<String> list=new ArrayList<String>();
		//PreparedStatement pstmt1;
		try
		{
		PreparedStatement	pstmt= connection.prepareStatement(sql);
		    ResultSet rs=pstmt.executeQuery();
			
		    while(rs.next()) {
		    	list.add(rs.getString(1));
		    }
		}catch(SQLException e)
		{
			e.printStackTrace();
		
		}
		
		return list;
		}
			public int showCountCategory(Connection conn, String category) {
		
		String sql="select count(movie_name)   from movies_master where movie_category=?";
		int count=0;
	//	Connection conn=null;
		try {
			PreparedStatement psmt= conn.prepareStatement(sql);
			psmt.setString(1, category);
		ResultSet  rs=psmt.executeQuery();		// TODO Auto-generated method stub
while(rs.next())
{
	count=rs.getInt(1);
}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return count;
	}
}




