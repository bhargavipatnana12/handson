package com.cts.SpringJavaConfig;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScans;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
@Configuration
@ComponentScan
public class JavaConfig {
	
	@Bean
	public Employee employee()
	{
		Employee emp=new Employee();
		emp.setId(100);
		emp.setSalary(29000);
		//System.out.println("employee");
		return emp;
	}

	
 @Bean
 @Qualifier("mybike")
	public Vehicle bike()//if we place bean annotation it will creayes obj directly
	{
		Bike bike=new Bike();
		bike.setName("hero");
		bike.setPrice(45000);
		//System.out.println("bike");
		
		return bike;
		
	}
 
	
 

 @Bean                                         //@Primary
 public Vehicle car()
	{
		Car car=new Car();
		car.setName("BMW");
		car.setPrice(90000);
		//System.out.println("employee");
		return car;
	}
	@Bean
	public DriverManagerDataSource datasource()
	{
		DriverManagerDataSource ds=new DriverManagerDataSource("jdbc:mysql://localhost:3306/mt_db" ,"root","root");
				return ds;
	}
	
	
	
	
}
