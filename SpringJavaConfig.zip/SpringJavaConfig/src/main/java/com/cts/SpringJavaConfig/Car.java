package com.cts.SpringJavaConfig;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component
@Primary
public class Car implements Vehicle {

	private String name;
	private int price;
	
	
	public String getName() {
		return name;
	}

public void setName(String name) {
		this.name = name;
	}
public int getPrice() {
		return price;
	}

public void setPrice(int price) {
		this.price = price;
	}


public void move() {
		System.out.println("Car    "+name+ "  which costs      "    +price+  "     runs   on 4 wheels" );
	}
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
