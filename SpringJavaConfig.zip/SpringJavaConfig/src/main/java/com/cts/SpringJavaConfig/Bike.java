package com.cts.SpringJavaConfig;

import org.springframework.stereotype.Component;

@Component
public class Bike implements Vehicle {
	private String name;
	private int price;
	
	
	public String getName() {
		return name;
	}

public void setName(String name) {
		this.name = name;
	}
public int getPrice() {
		return price;
	}

public void setPrice(int price) {
		this.price = price;
	}


public void move() {
		System.out.println("Bike    "+name+ "  which costs      "    +price+  "     runs   on 2 wheels" );
	}
	

}
