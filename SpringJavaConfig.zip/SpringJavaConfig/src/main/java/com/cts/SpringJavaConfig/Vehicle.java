package com.cts.SpringJavaConfig;

public interface Vehicle {
public void move();
	

	
	
}
