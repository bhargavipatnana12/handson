package com.cts.SpringJavaConfig;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

public class Example {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
 
		
		ApplicationContext ctx=new AnnotationConfigApplicationContext(JavaConfig.class);
		
		/*Employee emp=ctx.getBean(Employee.class);
		emp.showDetails();*/
		//System.out.println(emp.getId());
		//System.out.println(emp.getSalary());
		
DriverManagerDataSource	ds=	ctx.getBean(DriverManagerDataSource.class);
		Connection conn=ds.getConnection();
	//	Connection conn=null;
		//System.out.println(conn);
		Service service =new Service();
//		try {
//			conn=ds.getConnection("root","root");
//		}
//		catch(SQLException e) {
//		
//		{
//			e.printStackTrace();
//		}
		
		
		
		
	//	List<String> list=service.countActionMovies(conn);
	//	System.out.println(list);
		int count=service.countCustomer(conn);
		System.out.println("Customer count"+count);
		
		List<String> list1=service.countActionMovies(conn);
		System.out.println("CountActionMovies"+list1);
		
		
		int count1=service.showCountCategory(conn,"comedy");
		System.out.println("count of comedy movies:"+count1);
		
		int count2=service.showCountCategory(conn,"action");
		System.out.println("count of action movies:"+count2);
		
		int count3=service.showCountCategory(conn,"romance");
		System.out.println("count of romance movies:"+count3);
		
		
		}
	}

		
		
		
		
		
		
		
	


