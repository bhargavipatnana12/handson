package com.example.demo.model;

import javax.validation.constraints.Max;
//import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

public class Employee {

	
@Min(value =1, message="Enter Id")
private int id;	

@NotEmpty(message="Enter Name")
private String name;

@Max(value=100000,message="Enter Salary")
private int salary;

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public int getSalary() {
	return salary;
}

public void setSalary(int salary) {
	this.salary = salary;
}
}