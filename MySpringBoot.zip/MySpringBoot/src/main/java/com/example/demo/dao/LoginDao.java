package com.example.demo.dao;

//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;

//import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
//import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.example.demo.dbQuery.QueryConstants;
import com.example.demo.model.User;

@Repository
public class LoginDao {

//	@Autowired
//	DataSource datasource;
	
	@Autowired
	JdbcTemplate jdbcTemplate;

	public User fetchUser(User user) {
		// System.out.println(user.getName()+" "+user.getPassword());
       //    User user1= null;
          
         
//      User u=    jdbcTemplate.queryForObject(QueryConstants.SELECT_USER, user.getName(),new  RowMapper<user>()
//        		  {
//       @Override 	  
//    public User mapRow()    	  
//        	  user1=new Use();
//    user.setName(user.getName());
//    user.getPassword(rs.getString("password"));
//    
//    return user;
//        		  }
//	},user.getName());
//        	  
//        		  }
          
          // User u=    jdbcTemplate.queryForObject(QueryConstants.SELECT_USER, user.getName(),new  RowMapper<user>()
        	//	  {
//        @Override 	  
//     public User mapRow()    	  
//         	  user1=new Use();
//     user.setName(user.getName());
//     user.getPassword(rs.getString("password"));
 //    
//     return user;
//         		  }
// 	},user.getName());
          
         //		try {
//			Connection conn = datasource.getConnection();
//        //    PreparedStatement pstmt= conn.prepareStatement("select password from user where name=?");
//			PreparedStatement pstmt= conn.prepareStatement("QueryConstants.SELECT_USER");
//			pstmt.setString(1, user.getName());
//            ResultSet rs = pstmt.executeQuery();
//			while (rs.next()) {
//
//				user1 = new User();
//                user1.setName(user.getName());
//				user1.setPassword(rs.getString("password"));
//			}
//			// pstmt.setString(1, user.getName());
//		}
//		catch (Exception e){
//			
//			e.printStackTrace();
//		}
//		return user1;
//	}


return 	 jdbcTemplate.queryForObject(QueryConstants.SELECT_USER,  (r,n)   ->{
		
		User user2=new User();
		
		 user2.setName(user.getName());
			user2.setPassword(r.getString("password"));
			
			return user2;
        		  },user.getName());
			
			
		}
		
}
