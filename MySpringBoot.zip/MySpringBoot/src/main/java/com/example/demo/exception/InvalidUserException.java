package com.example.demo.exception;

public class InvalidUserException extends Exception
{
 public InvalidUserException(String s) 
{
      super(s);
    }

}
