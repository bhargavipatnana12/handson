package com.example.demo.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.example.demo.dbQuery.QueryConstants;
import com.example.demo.model.Employee;

@Repository 
public class EmployeeDao {

	@Autowired
	JdbcTemplate jdbcTemplate;
	
	public int registerEmployee (Employee employee) {
		
	try {
			return jdbcTemplate.update(QueryConstants.INSERT_EMP, employee .getId(),employee.getName(),employee.getSalary());
		}catch(Exception e){
			return 0;
		}
		
	}
	
	public Employee getEmployee(int id) {
		
	try {
		return   jdbcTemplate.queryForObject(QueryConstants.SEARCH_EMP,(rs,r)->{
	
		Employee employee=new Employee();
		employee.setId(rs.getInt("id"));
		employee.setName(rs.getString("name"));
		employee.setSalary(rs.getInt("salary"));
		return employee;
	},id);
	
	}catch(Exception e) {
		return null;
	}
}
	public List<Employee>  getAll()
	{
	return 	jdbcTemplate.query(QueryConstants.ALL_EMP,(rs,r)->
			{
	
			
		Employee emp=new Employee() ;
		emp.setId(rs.getInt("id"));
		emp.setName(rs.getString("name"));
		emp.setSalary(rs.getInt("salary"));
		return emp;
	});
			
}	
	
	public int deleteEmployee(int id) {
		return jdbcTemplate.update(QueryConstants.DELETE_EMP ,id);
			
	}
//		try{	
			
	//		Employee employee=new Employee();
//			employee.setId(rs.getInt("id"));
//			
//			return employee;
//		},id);
//		
//		}catch(Exception e) {
//			return null;
//		}
	
	
		
	
}
			
