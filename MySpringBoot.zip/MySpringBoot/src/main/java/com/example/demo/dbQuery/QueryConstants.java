package com.example.demo.dbQuery;

public interface QueryConstants {
   
	
	public String SELECT_USER="Select  password from user where name=?";
	
	public String INSERT_EMP="insert into employee values(?,?,?)";
	
	
	
	public String SEARCH_EMP="select * from employee where id=?";
	
	
	public String ALL_EMP="select * from employee";
	
	public String DELETE_EMP=" delete from employee where ID=4";
}
