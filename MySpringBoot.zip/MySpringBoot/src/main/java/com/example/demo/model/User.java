package com.example.demo.model;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
//import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

public class User {
	
	@NotEmpty(message ="Enter name")
@Pattern(regexp ="^[a-z] {1}.*$",message ="Starting with Capital")
private String name;


@NotEmpty(message="Enter password")
@Pattern(regexp=".{5,}" ,message="Five or more characters")
private String password;


public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public static int insertUser(@Valid User user) {
	// TODO Auto-generated method stub
	return 0;
}

	
	
}
