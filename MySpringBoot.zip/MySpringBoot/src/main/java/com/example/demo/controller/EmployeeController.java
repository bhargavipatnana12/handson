package com.example.demo.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.bo.EmployeeBo;
//import com.example.demo.dao.EmployeeDao;
import com.example.demo.model.Employee;

@Controller
public class EmployeeController {
	@Autowired
	EmployeeBo employeeBo;

	@GetMapping("/register")
	public String registerEmp(@ModelAttribute("employee") Employee employee) {
		return "register";
	}

	@PostMapping("/registerEmployee")
	public String insertEmployee(@Valid Employee employee, BindingResult result, Model model) {

		if (result.hasErrors()) {
			//System.out.println("hello");	
			return "register";
		}

		if (employeeBo.insertEmployee(employee) == 1) {

			model.addAttribute("success", "Employee added successfully");
			return "home";

		} else {
			model.addAttribute("id Error", "Employee id does not sexist");
			return "register";
		}
	}

	@GetMapping("searchEmployee")
	public String searchEmp() {
		return "search";
	}

	@GetMapping("findEmployee")
	public String findEmp(@RequestParam int id, Model model) {

		Employee employee = employeeBo.findEmployee(id);
		if (employee != null) {
			model.addAttribute("emp", employee);
			return "home";

		} else {
			model.addAttribute("emp1", "No such Employee");
			return "home";
		}

	}
	
	@GetMapping("getAll")
	public String findAll(Model model)
	{
		
		model.addAttribute("AllEmp" ,employeeBo.getAllEmp());
			return "home";
		
	}
	
	
	@GetMapping("deleteEmployee")
public 	String deleteEmp(@RequestParam int id, Model model) {
		
		int employee=employeeBo.deleteEmployee(id);
			if (employee ==1) {
			model.addAttribute("emp2", "Employee deleted successfully.......");
			return "home";

		} else {
			model.addAttribute("emp3", "No such Employee found");
			return "home";
		}
}
	}	
	
	
	
	

