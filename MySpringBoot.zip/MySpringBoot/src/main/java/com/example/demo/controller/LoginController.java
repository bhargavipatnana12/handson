package com.example.demo.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import com.example.demo.bo.LoginBO;
import com.example.demo.exception.InvalidUserException;
import com.example.demo.model.User;
@Controller
public class LoginController {
	
	@Autowired
	LoginBO loginBo;
	
	@GetMapping("/home")
	public String login(@ModelAttribute("user")   User user)
	{
		return "index";
	}
	@PostMapping("/loginUser")
        public String userLogin(@Valid User user,BindingResult result,HttpServletRequest request,Model model)  {
        	
    	if(result.hasErrors()) {
			
			System.out.println("it has errors");
			return "index";
		}
		
		try {
    		boolean flag=loginBo.validateUser(user);
    	//	if(flag) {
    			
    		
    		HttpSession session=request.getSession();

    		  session.setAttribute("username", user.getName());
    		
    			//model.addAttribute("userName",user.getName());
    			return "home";
    			}
    		catch(InvalidUserException e) {
    			model.addAttribute("error",e.getMessage());
    				return "index";
    			}
	}

@PostMapping("/registerUser")
public 	String insertUser(@Valid User user, BindingResult result,Model model) {
	
	if(result.hasErrors()) {
		return "registration";
	
	
}
		if (loginBo.insertUser(user) ==1) {
		model.addAttribute("success", "user added successfully.......");
		return "home";

	} else {
		model.addAttribute("idError", "Use id exist");
		return "registration";
	}
}    
}



	
