package com.example.demo.bo;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.LoginDao;
import com.example.demo.exception.InvalidUserException;
import com.example.demo.model.User;

@Service
public class LoginBO  {
	
	@Autowired
	LoginDao loginDao;
public boolean validateUser(User user) throws InvalidUserException {

	
		User u=loginDao.fetchUser(user);
	if(u!=null) {
	
	if(u.getName().equals(user.getName())  &&     u.getPassword().equals(user.getPassword())) {
	return true;
	}else {
		 throw new    InvalidUserException("Invalid user");
	}
	}
	else 
	{
	 throw new    InvalidUserException("Invalid user");
	 }
}
public int insertUser(@Valid User user) {
	// TODO Auto-generated method stub
	return 0;
}

}

		
		
		
		
	
	


