package com.example.demo.bo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.EmployeeDao;
import com.example.demo.model.Employee;

@Service
public class EmployeeBo {

	@Autowired
	EmployeeDao employeeDao;
	
	public int insertEmployee(Employee employee) {
		
		return employeeDao.registerEmployee(employee);
	}
	
	
	public Employee findEmployee(int id)
	{
		return employeeDao.getEmployee(id);
	}
	
	
	public List<Employee> getAllEmp()
	{
		return employeeDao.getAll();
	}
	
	public int  deleteEmployee(int id)
	{
		return employeeDao.deleteEmployee(id);
	}
	
	
	
	
	}
