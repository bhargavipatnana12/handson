package com.cts.sql;
import java.lang.*;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.function.BinaryOperator;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Function;


//import javax.sql.RowSet;


public class Example {
public static void main(String args[])
{
	   //       Employee emp=new Employee();
/*             emp.id=3444;
               emp.name="sss";
                emp.setSalary(0);
           
                 System.out.println(emp.id);
                System.out.println(emp.name);
                 System.out.println(emp.getSalary());

                 
emp.setId(100);
emp.setName("abc");
emp.setSalalry(0);

System.out.println(emp.getId());
System.out.println(emp.getName());
System.out.println(emp.getSalalry());*/
	          List<Integer> list=new ArrayList<Integer>();
	          list.add(2);
	          list.add(3);
	          list.add(5);
	          list.add(6);
	          list.add(8);
	          
	       //  list.forEach(new MyConsumer()); 

//letc(t->System.out.println(t));  ///lambda
//letc(System.out ::println); ///method reference

	
//}
//            public static void letc(Consumer c) {
//	               c.accept(10);


//class MyConsumer implements Consumer<Integer>{
//	@Override
//	public void accept(Integer t) {
//		System.out.println(t);
	          
                           /*  FI */
	          
//	      list.forEach(new Consumer<Integer>() 
//	      {
//	   @Override
//	      public void accept(Integer t) {
//	    	  System.out.println(t);
//	      }
//	      });
          
	      
	    //////////////Lambda Expression/////////////  
	          
//	          list.forEach(t->
//	        	  System.out.println(t));
          
	         // list.stream().forEach(System.out.println(list));          
	  //        list.stream().filter(predicate).forEach(System.out::println);         
	          
	     /*     list.stream().filter(new Predicate<Integer>() {
	        	  @Override
	        	  public boolean test(Integer t) {
	        		  return false;
	        	  }
	          })
	          
	        	  .forEach(System.out::println); */
	     
	//          }
	          
	      /*    list.stream()
	         .filter(t->t%2==0)
	          .forEach(System.out::println); 
	         
Predicate<Integer> p;

		}*/
	          

                              /*   list.stream()
                           .filter(t->t%2==0)
                            .map(new Function<Integer,Integer>(){
	@Override
	public Integer apply(Integer t) {
		return t+10;
	}
})
 .forEach(System.out::println); */
	          
	          
	          
	     //     list.stream().filter(t->t%2==0) .map(t->t+10).forEach(System.out::println); 

	          
	          
	          
//	          list.stream()
//              .filter(t->t%2==0)
//               .map(new Function<Integer,Integer>(){
//@Override
//public Integer apply(Integer t) {
//return t+10;
//}
//})
//               .distinct()
//               .limit(3)
//               .sorted()
//               .reduce(new BinaryOperator<Intege>() {
//            	   
//            	   @Override
//            		public Integer apply(Integer t, Integer u) {
//            			return t+u;
//            		}
//               });
            	   
            	   
              
               
//.forEach(System.out::println); 
	          
	int k= list.stream( )
           .filter(t->t%2==0)
           .map(t->t+10)
        	   .distinct()
            .limit(3)
           .sorted()
           .reduce(new BinaryOperator<Integer>() {
          	   
        	   @Override
                  public Integer apply(Integer t,Integer u) {
                 return t+u;
        	   }
}).get();
     System.out.println(k);
          	
}

    }







