package com.cts.sql;

import java.beans.Statement;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Scanner;

public class SqlConnect {

	
	public static void main(String[] args) {
		
	Connection conn=null;
	Statement stmt=null;
	
	
	try {
		Cass.forName("com.mysql.cj.jdbc.Driver");
	
	
	
    
    // Establish connection
     conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydatabase", "root", "root");
    // executing statement
   //-------------  stmt=conn.createStatement();
     
     
     Scanner sc=new Scanner(System.in);
     System.out.println("Enter id");
     int id=sc.nextInt();
     System.out.println("Enter name");
     int name=sc.nextInt();
     System.out.println("Enter salary");
     int sal=sc.nextInt();
     stmt.execute()"insert into employee values("+id+")");
     
     System.out.println("Data fetched successfully");
   //  stmt.execute()"insert into employee values("+id+","+name+","+sal+")");
   //  System.out.println("Data inserted successfully");
	}
	catch(Exception e) {
		e.printStackTrace();
	}finally {
		try {
			conn.close();
		}catch (SQLException e) {
			e.printStackTrace();
		}
	
	}
	
//	sql="select * from employee";
//     
//     ResultSet rs=stmt.executeQuery(sql);
//     
//     while(rs.next()) {
//         int id=rs.getInt("id");
//         String name=rs.getNString("name");
//         int salary=rs.getInt("salary");
//         
//         System.out.println(id+"  "+name+"  "+salary);
//     }
//    
//     
//     System.out.println("Data fetched successfully");
//    
//}
