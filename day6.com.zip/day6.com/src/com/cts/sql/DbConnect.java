package com.cts.sql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

public class DbConnect {

			public static void main(String[] args) {
				// TODO Auto-generated method stub
        Connection conn=null;
           Statement stmt=null;
//PreparedStatement pstmt=null;

		try{
            Class.forName("com.mysql.cj.jdbc.Driver");

		 conn=DriverManager.getConnection("jdbc:mysql://localhost:3305/mydatabase","root","root");

		stmt=conn.createStatement();

		// stmt.execute("update employee set name='sruthi' where empid=1");

		// String sql="select * from employee";

		// ResultSet rs=stmt.executeQuery(sql);

//		 while(rs.next())
//
//		 {
//
//		 int id=rs.getInt("id");
//
//		 String name=rs.getString("name");
//
//		 String salary=rs.getString("salary");
//
//		 System.out.println(id+" "+name+" "+salary);
//
//		 }
//
//		 Scanner sc=new Scanner(System.in);
//
//		 System.out.println("enter name");
//
//		 String name=sc.next();
//
//		 System.out.println("enter id");
//
//		 int id=sc.nextInt();
//
//		 System.out.println("enter salary");
//
//		 String salary=sc.next();
//
////		 System.out.println("enter id");
//
////		 int empid=sc.nextInt();
//
//
//
//
//
//	stmt.execute("insert into employee values('"+id+"','"+name+"', '"+salary+"'')");

	//	 System.out.println("Data fetched successfully");

		

//		 try {
//
//		  Class.forName("com.mysql.cj.jdbc.Driver");
//
//		  conn=DriverManager.getConnection("jdbc:mysql://localhost:3305/emp","root","root");
//
//		 String sql="insert into employee values(?,?,?,?)";
//
//		 pstmt.setString(1,"sais");
//
//		 pstmt.setInt(2,20);
//
//		 pstmt.setString(3,"ece");
//
//		 pstmt.setInt(1,100);
//
//		 pstmt.execute();
//
//		 System.out.println("inserted successfully");



		 }



		catch(Exception e) {

		 e.printStackTrace();

		}finally {

		 try {

		 conn.close();



		 }catch(SQLException e)
		 {
			 
		 }

		} 
		}
}


