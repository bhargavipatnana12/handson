package com.cts.sql;

public class MultiThread {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
class Account implements Runnable{
	int bal=1000;
	public void run()
	{
}
}
	}

}
