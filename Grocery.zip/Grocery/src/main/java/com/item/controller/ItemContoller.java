package com.item.controller;

import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.item.bo.ItemBo;
import com.item.model.Item;

@Controller
public class ItemContoller {
	@Autowired
	ItemBo itemBo;

	@GetMapping("/register")
	public String registerItem(@ModelAttribute("item") Item item) {
             return "register";

	}

	@PostMapping("registerItem")
     public String registerItem(@Valid Item item, BindingResult result, Model model) {
           if (result.hasErrors()) {
            // System.out.println("it has errors");
			return "register";

		}
           if (itemBo.insertItem(item) == 1) {

			model.addAttribute("success", "Item added successfully");
           // System.out.println("Employee added successfully");
           return "home";

		} else

		{
          model.addAttribute("idError", "Could not add item");
          // System.out.println("doesnot Exist");
            return "register";

		}
	}

	@GetMapping("searchItem")
	public String searchItem() {
		return "search";
	}

	@GetMapping("findItem")
	public String findItem(@RequestParam int itemId, Model model) {

		Item item = itemBo.findItem(itemId);
		if (item != null) {
			model.addAttribute("item", item);
			return "home";

		} else {

			model.addAttribute("item1", "No such Item");
			return "home";

		}
	}

	@GetMapping("show")
	public String findAll(Model model) {
		model.addAttribute("allItems", itemBo.getAllItem());
		return "home";
	}

	@GetMapping("delItem")//get the user id from user
	public String deleteItem() {
     return "delete";

	}


 @GetMapping("deleteItem")//delete items from database

public String deleteItem(@RequestParam int itemId, Model model)
{
int item = itemBo.deleteItem(itemId);

 if (item == 1) {
model.addAttribute("item2", "item deleted");
 return "home";

	 } else {

  model.addAttribute("item3", "No such item");
   return "home";
	 }
	 }
}