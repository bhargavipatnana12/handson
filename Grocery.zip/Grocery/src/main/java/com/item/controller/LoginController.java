package com.item.controller;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import com.item.bo.LoginBo;
import com.item.exception.InvalidUserException;
import com.item.model.User;


@Controller
public class LoginController {

	 @Autowired
      LoginBo loginBo;

      @GetMapping("/home")
	 public String login(@ModelAttribute("user") User user) {
      return "index";
	 }
      
      @PostMapping("/LoginUser")
     public String userLogin(@Valid User user, BindingResult result, HttpServletRequest request, Model model) { 
    	  {
    	  if (result.hasErrors()) {

       HttpSession session = request.getSession();
         session.setAttribute("error", "invalid username or password.Please try again");
         return "index";

         } 
    	  else {
         try {

      boolean falg = loginBo.validateUser(user);
     HttpSession session = request.getSession();
     session.setAttribute("name", user.getName());
     return "home";
    
         } catch (InvalidUserException e) {
       model.addAttribute("error", e.getMessage());
       return "index";
     }
    	  }
         }
      }
      
      

      
      @GetMapping("registeruser")
      public String registerUser(@ModelAttribute("user") User user) {

              return "registeruser";
         }

      @PostMapping("adduser")
     public String registerUser(@Valid User user,BindingResult result,Model model) {

    	  if(result.hasErrors()) {
    	 return "register";
 }

           if(loginBo.addUser(user)==1) {

                model.addAttribute("success1","user added successfully.");
                return "index";

            }else {
                  model.addAttribute("idError","User does not exist");
                  return "register";

     }
     }
     }