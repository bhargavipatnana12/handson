package com.item.dbQuery;

public interface QueryConstants {

	 public String SELECT_USER="select password from user where name=?";
	// public String FETCH_ITEM="";
	 public String INSERT_ITEM="insert into item values(?,?,?,?)";


	 public String SEARCH_ITEM="select * from item where itemId=?";

	 public String DELETE_ITEM="Delete from item where itemId=?";
	  public String ALL_ITEMS="select * from item";

	 public String ADD_USER="insert into user values(?,?)";
	
	
	
}
