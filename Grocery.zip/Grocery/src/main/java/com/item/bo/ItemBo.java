package com.item.bo;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.item.Dao.ItemDao;
import com.item.model.Item;

@Service
public class ItemBo {
	@Autowired
	ItemDao itemDao;

	 public int insertItem(Item item)
	 {
 return itemDao.registerItem(item);
	 }
	 
	 public Item findItem(int itemId)
 {
 return itemDao.getItem(itemId);
				 }
	 
	 
	 public List<Item> getAllItem(){

 return itemDao.getAllItem();
 }


	 public int deleteItem(int itemId)

 {
		 return itemDao.deleteItem(itemId);

	}
	
	
}