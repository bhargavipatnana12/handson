package com.item.bo;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.item.Dao.LoginDao;
import com.item.exception.InvalidUserException;
import com.item.model.User;

@Service
public class LoginBo {
	@Autowired
	LoginDao loginDao;

	public boolean validateUser(User user) throws InvalidUserException {

		User u=loginDao.fetchUser(user);
	if(u!=null) {
	
	if(u.getName().equals(user.getName())  &&     u.getPassword().equals(user.getPassword())) {
	                         return true;
	}else {
		 throw new    InvalidUserException("Invalid user");
	}
	}
	else 
	{
	 throw new    InvalidUserException("Invalid user");
	 }
}
public int addUser (User user) {
	// TODO Auto-generated method stub
	return loginDao.addUser(user);
}

}

		
		
		
		

	


