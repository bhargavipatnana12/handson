package com.item.Dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.item.dbQuery.QueryConstants;
import com.item.model.Item;
@Repository
public class ItemDao {
	 @Autowired

	 JdbcTemplate jdbcTemplate;
 public int registerItem(Item item) {

//	 //System.out.println("hello");
	 int temp=1;
try {

  return jdbcTemplate.update(QueryConstants.INSERT_ITEM, item.getItemId(),item.getItemName(),item.getItemPrice(),item.getItemBrand());

	 } catch (Exception e) {

  e.printStackTrace();
  temp=0;
	 }
 return temp;
	 
 }

public Item getItem(int itemId) {

try {

 return jdbcTemplate.queryForObject(QueryConstants.SEARCH_ITEM,(rs,r)->{
	 
 
		 Item  item=new Item();
	 item.setItemId(rs.getInt("itemId"));
        item.setItemName(rs.getString("itemName"));
        item.setItemPrice(rs.getString("itemPrice"));
        item.setItemBrand(rs.getString("itemBrand"));
		

	 return item;

},itemId);

	}catch(Exception e)

 {

	 return null;
      }
}

	 public List<Item> getAllItem()    {

 return jdbcTemplate.query(QueryConstants.ALL_ITEMS,(rs,r)->{

	 Item  item=new Item();
    item.setItemId(rs.getInt("itemId"));
     item.setItemName(rs.getString("itemName"));
     item.setItemPrice(rs.getString("itemPrice"));
     item.setItemBrand(rs.getString("itemBrand"));
    

 return item;
 });

 
	}

	public int deleteItem(int itemId)  {

	 return jdbcTemplate.update(QueryConstants.DELETE_ITEM,itemId);

	}


}
	