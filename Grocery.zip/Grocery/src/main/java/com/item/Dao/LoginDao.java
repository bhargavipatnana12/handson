package com.item.Dao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import com.item.dbQuery.QueryConstants;
import com.item.model.User;


@Repository
public class LoginDao {
	 @Autowired

	 JdbcTemplate jdbcTemplate;

	 public User fetchUser(User user) {
		 
					

      return jdbcTemplate.queryForObject(QueryConstants.SELECT_USER,(r,n)->{

	  User user1=new User();
	  user1.setName(user.getName());
      user1.setPassword(r.getString("password"));
      return user1;

       }, user.getName());

 }
	 public int addUser(User user)

	 {
	 //System.out.println("hello");
	 int temp=1;
	 try {


 return jdbcTemplate.update(QueryConstants.ADD_USER, user.getName(),user.getPassword());

	 } catch (Exception e) {

	 e.printStackTrace();

temp=0;

	 }

	return temp;
 }}







