package com.item.model;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;


public class User {
	
	@NotEmpty(message="Name  cannot be empty")
	private String name;
	
	@NotEmpty()
	@ Pattern(regexp="[a-zA-Z_][0-9a-zA-Z_]*",message="")
	 private String password;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}


