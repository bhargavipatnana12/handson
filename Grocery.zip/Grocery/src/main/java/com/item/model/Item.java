package com.item.model;


import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;


public class Item {
	
	@Min(value=1)
private 	int itemId;
	
	@NotEmpty(message ="Enter itemName")
private	String itemName;

	@NotEmpty(message ="Enter itemPrice ")
    private	String  itemPrice;

	@NotEmpty(message ="Enter BrandName")
   private	String itemBrand;

	
	public int getItemId() {
		return itemId;
	}
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public String getItemPrice() {
		return itemPrice;
	}
	public void setItemPrice(String itemPrice) {
		this.itemPrice = itemPrice;
	}
	public String getItemBrand() {
		return itemBrand;
	}
	public void setItemBrand(String itemBrand) {
		this.itemBrand = itemBrand;
	}
}