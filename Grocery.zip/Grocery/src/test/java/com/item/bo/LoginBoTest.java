package com.item.bo;

import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.item.model.User;

@SpringBootTest
public class LoginBoTest {

     @Autowired
     LoginBo loginBo;

       User user=null;

       @BeforeEach
        void setUp() throws Exception{

        user=new User();
        user.setName("sruthi");
        user.setPassword("sruthi25");

	 }

	 @AfterEach
     void tearDown() throws Exception{

	 }

	 @Test
	 void testValidateUser() {

	 boolean flag;

	 try {

	  flag=loginBo.validateUser(user);

	  if(flag) {

	  assertTrue(true);

	  }else {

	  assertTrue(false);

	  }

	 }catch(Exception e)

	 {

	  assertTrue(false);

	 }

	 }

	}

